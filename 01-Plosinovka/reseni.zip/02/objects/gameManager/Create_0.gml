greenKeys = 1;
mince=0;

playerReturning = false;
