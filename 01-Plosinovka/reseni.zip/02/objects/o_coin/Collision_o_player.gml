gameManager.mince += 1;     // other = hráč
//audio_play_sound(snd_coin, 1, false);
instance_destroy();   // mince zmizí

audio_play_sound(z_mince, 1, 0)