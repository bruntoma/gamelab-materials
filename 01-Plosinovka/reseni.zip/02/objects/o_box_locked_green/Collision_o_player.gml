if (gameManager.greenKeys > 0)
{
	player_blink = true
	image_alpha=0
}
