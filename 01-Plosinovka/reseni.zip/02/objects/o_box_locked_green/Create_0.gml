player_blink = false
time = 0
frequency=0.1
blink_max_mul=1
blink_min_mul=0.9
duration = 300
player_orig_color = o_player.image_blend

orig_rychlost = o_player.max_rychlost