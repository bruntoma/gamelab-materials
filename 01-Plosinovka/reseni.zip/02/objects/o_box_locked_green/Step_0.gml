
if (player_blink)
{
	if (time > duration)
	{
		player_blink = false
		o_player.image_blend = player_orig_color
		o_player.max_rychlost = orig_rychlost
		instance_destroy()
	}
	else
	{
	
		mul = blink_max_mul * sin(frequency * time) + blink_min_mul
	
		var color = make_colour_hsv(85*mul, 125*mul, 255)
		
		show_debug_message(mul)
		o_player.image_blend = color;
		o_player.max_rychlost = 20
	
		time++;
		show_debug_message(mul)
	}
}


